import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import {MatSnackBar , MatSnackBarRef} from '@angular/material/snack-bar';
import {AcceptCookiesComponent} from '../accept-cookies/accept-cookies.component';
import { DemoFormComponent } from '../demo-form/demo-form.component';
import { FormFillingSuccessfulComponent } from '../form-filling-successful/form-filling-successful.component';
import { SubscriptionSuccessfulComponent } from '../subscription-successful/subscription-successful.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  // durationInSeconds = 5;
  constructor(private _snackBar: MatSnackBar,public dialog: MatDialog ) { }
  menutoggle(){
    // document.getElementById("OpenMenu").toggleClass("active");
  }
 subscribesuccessfully(){
   this._snackBar.openFromComponent(SubscriptionSuccessfulComponent);
 }
 DemoForm(){
  const dialogRef = this.dialog.open(DemoFormComponent);
 }
  ngOnInit(): void {
    let snackBarRef = this._snackBar.openFromComponent(AcceptCookiesComponent, {
      // duration: this.durationInSeconds * 1000,
    });
  }
  }


