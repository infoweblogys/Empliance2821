import { Component, OnInit } from '@angular/core';
import { MatSnackBarRef } from '@angular/material/snack-bar';

@Component({
  selector: 'app-subscription-successful',
  templateUrl: './subscription-successful.component.html',
  styleUrls: ['./subscription-successful.component.scss']
})
export class SubscriptionSuccessfulComponent implements OnInit {

  constructor(public snackBarRef: MatSnackBarRef<SubscriptionSuccessfulComponent>) { }

  ngOnInit(): void {
  }

}
