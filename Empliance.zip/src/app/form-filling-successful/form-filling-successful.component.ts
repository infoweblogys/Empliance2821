import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-filling-successful',
  templateUrl: './form-filling-successful.component.html',
  styleUrls: ['./form-filling-successful.component.scss']
})
export class FormFillingSuccessfulComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
