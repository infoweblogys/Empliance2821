import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormFillingSuccessfulComponent } from './form-filling-successful.component';

describe('FormFillingSuccessfulComponent', () => {
  let component: FormFillingSuccessfulComponent;
  let fixture: ComponentFixture<FormFillingSuccessfulComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FormFillingSuccessfulComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FormFillingSuccessfulComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
