import { Component, OnInit } from '@angular/core';
import { MatSnackBarRef} from '@angular/material/snack-bar';
@Component({
  selector: 'app-accept-cookies',
  templateUrl: './accept-cookies.component.html',
  styleUrls: ['./accept-cookies.component.scss']
})
export class AcceptCookiesComponent implements OnInit {

  constructor( public snackBarRef: MatSnackBarRef<AcceptCookiesComponent>) { }
  
  ngOnInit(): void {
  }

}
